package vn.dbutil;
import java.sql.*;

public class DbConnection {
	
	private static Connection con;
	
	public static Connection openConnection() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/notes_db","root","root");
		}
		catch(ClassNotFoundException|SQLException cse) {
			
			cse.printStackTrace();
		}
		return con;
	}
	/*
	 * public static void main(String[] args) { Connection c=openConnection();
	 * System.err.println(c); }
	 */

}
