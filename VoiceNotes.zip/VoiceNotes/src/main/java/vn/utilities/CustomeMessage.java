package vn.utilities;

public class CustomeMessage {
	
	public static final String LOGIN_ERROR="Invalid credentails";
    public static final String AUTHORISE_ERROR="UnAuthorised Access";
		
	}

