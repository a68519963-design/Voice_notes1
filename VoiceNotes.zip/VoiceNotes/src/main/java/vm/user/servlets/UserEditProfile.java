package vm.user.servlets;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import voicenotes.beans.User;
import voicenotes.dao.UserDao;

/**
 * Servlet implementation class UserEditProfile
 */
@WebServlet("/UserEditProfile")
@MultipartConfig
public class UserEditProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserEditProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Part p=request.getPart("profilepic");
		
		String fileName=p.getSubmittedFileName();
		long size=p.getSize();
		
		System.out.println("file Name:"+fileName+"and size:"+size);
	    ServletContext sc=getServletContext();
	    String serverPath=sc.getRealPath("");
	    
	    System.out.println("path is"+serverPath);
		   String folderName="profileImages";
		   String fullPath=serverPath+folderName;
		   
		   File f=new File(fullPath);
		   String picPath="";
		   String dbPath="";
		   
		   if(!f.exists()) {
			   f.mkdir();
			   System.out.println("Directory created");
		   }
		   picPath=fullPath+File.separator+fileName;
		   dbPath=folderName+File.separator+fileName;
		   
			/* p.write(picPath); */
		   try {
	            p.write(picPath);
	            System.out.println("File uploaded successfully.");
	        } catch (IOException e) {
	            System.out.println("Error writing file: " + e.getMessage());
	            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "File upload failed.");
	            return;}
		
		
		
		String uName=request.getParameter("name");
		String uPhone=request.getParameter("phone");
		String uAddress=request.getParameter("Address");
		String uCity=request.getParameter("city");
		
		//to indentify logged In user
		
		HttpSession hs=request.getSession(false);
		
		String email=(String)hs.getAttribute("sessionEmail");
		
		User u=new User();//creating beans class objects
		u.setName(uName);
		u.setCity(uCity);
		u.setPhone(uPhone);
		u.setEmail(email);
		u.setAddress(uAddress);
		u.setProfile_pic(dbPath);
		
		UserDao dao=new UserDao();//dao class object
		
		
	int status=	dao.editProfile(u,email);
		
				if(status>0){
					response.sendRedirect("/VoiceNotes/user/user_home.jsp");
				}
		
	}

}
