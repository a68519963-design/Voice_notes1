package voicenotes.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import vn.dbutil.DbConnection;
import voicenotes.beans.User;
import voicenotes.beans.UserFeedback;

public class UserDao {
	
	private static final int VoiceNotes = 0;
	private Connection con;

	
//<----------------method to checking in the feedback table----//
	
	public boolean checkEmail(String email) {
		String strsql="select email from userfeedback where email=?";
		con=DbConnection.openConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			ps=con.prepareStatement(strsql);
			ps.setString(1, email);
			rs=ps.executeQuery();	
		    if(rs.next())
		    	return true;
		}
		
		catch(SQLException se) {se.printStackTrace();}
		//finally{}
		return false;
	}
	

	public int addFeedback(UserFeedback fd) {

     // Feedback bao this place create//
		
		  int status=0; 
		  con=DbConnection.openConnection(); 
		  //id, name, email, rating, remarks, date-field names
		  
		    PreparedStatement ps=null;
		  
		  try {
			  //check for email existance 
			  String query="";
			  if(checkEmail(fd.getEmail())==false)
			  {
			  query="insert into userfeedback(name, email, rating, remarks, date)values(?,?,?,?,?)" ;
			  
			  
			  ps=con.prepareStatement(query);
				 ps.setString(1,fd.getName());
			  ps.setString(2,fd.getEmail());
			  ps.setString(3,fd.getRating());
			  ps.setString(4,fd.getRemarks()); 
			  ps.setDate(5,fd.getDate());
			  System.out.println(ps); 
			  status=ps.executeUpdate(); 
			  
			  
			  
			  }
			  else
			  {
				  query="update userfeedback set rating=?,remarks=?,date=? where email=?";
				  
				  
				  
				  
				  ps=con.prepareStatement(query);
				  ps.setString(1,fd.getRating());
				  ps.setString(2,fd.getRemarks()); 

				  ps.setDate(3,fd.getDate());
				  ps.setString(4,fd.getEmail());
				 
				  System.out.println(ps); 
				  status=ps.executeUpdate(); 
				  System.out.println("remarks status is "+status);
			  }
				/*
				 * String
				 * strInsert="insert into userfeedback(name, email, rating, remarks, date)values(?,?,?,?,?)"
				 * ;
				 */
			  
			 
		  }
		  
		  
		  catch(SQLException se) {
		  se.printStackTrace();
		  
		 }
		  
		  finally {
				try {
					if(ps!=null)
						ps.close();
					if(con!=null)
						con.close();
				}
				catch(SQLException se) {
					se.printStackTrace();
				}
			}
			return status;
	}
		 
	 
	public int userRegistration(User u) {
		int status=0;
		con=DbConnection.openConnection();
		
		String strInsert="insert into user(email, password, name, phone, city, address, profile_pic, date)values(?,?,?,?,?,?,?,?)";
		PreparedStatement ps=null;
		try {
			ps=con.prepareStatement(strInsert);
			ps.setString(1,u.getEmail());
			ps.setString(2,u.getPassword());
			ps.setString(3,u.getName());
			ps.setString(4,u.getPhone());
			ps.setString(5,u.getCity());
			ps.setString(6,u.getAddress());
			ps.setString(7,u.getProfile_pic());
			ps.setDate(8,u.getDate());
			System.out.println(ps);
			status=ps.executeUpdate();
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		
		finally {
			try {
				if(ps!=null)
					ps.close();
				if(con!=null)
					con.close();
			}
			catch(SQLException se) {
				se.printStackTrace();
			}
		}
		return status;


}
	public boolean checkLogin(String email, String password) {
		con=DbConnection.openConnection();
	    PreparedStatement ps=null;
	    ResultSet rs=null;
	    String selectqurey="select *  from user where email=? and password=?";
	    
	    try {
	    	ps=con.prepareStatement(selectqurey);
	    	ps.setString(1, email);
	    	ps.setString(2,password);
	    	System.out.println(ps);
	    	rs=ps.executeQuery();
	    	
	    	if(rs.next()==true) //if shows that email and password exits
	    	{
	    		return true;
	    	}
	    	
	    	
	    }
	    catch(SQLException se){
	    	se.printStackTrace();
	    	
	    }
		return false;
	}
	
	
	//view userprofile  method
	
	
	public User userProfile(String emailId)
	{
		con=DbConnection.openConnection();
		String selectQuery="select *from user where email=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		User u=null;
		
		try {
			ps=con.prepareStatement(selectQuery);
			ps.setString(1,emailId);
			System.out.println(ps);
			rs=ps.executeQuery();
			rs.next();
			
			
			
			
			
			//email, password, name, phone, city, address, profile_pic, date
			
			String uname=rs.getString("name");
			String uPhone=rs.getString("phone");
			String uCity=rs.getString("city");
			String uAddress=rs.getString("address");
			String uProfile_pic=rs.getString("profile_pic");
			String uPassword=rs.getString("password");
			u=new User();
			
			u.setEmail(emailId);
			u.setName(uname);
			u.setAddress(uAddress);
		    u.setCity(uCity);
		    u.setPassword(uPassword);
			u.setPhone(uPhone);
			u.setProfile_pic(uProfile_pic);
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		
		return u;
	
}


	public static void main(String[] args) {
		
	}

	//email, password, name, phone, city, address, profile_pic, date

	public int editProfile(User u, String email) {
		int status = 0;
		con = DbConnection.openConnection();
		PreparedStatement ps = null;
		try {
			String updateQuery = "update user set phone=?,name=? ,city=? , address=?,profile_pic=? where email=?";
			ps = con.prepareStatement(updateQuery);
			ps.setString(1, u.getPhone());
			ps.setString(2, u.getName());
			ps.setString(3, u.getCity());
			ps.setString(4, u.getAddress());
			ps.setString(5, u.getProfile_pic());
			ps.setString(6,u.getEmail());
			System.out.println(ps);
			status = ps.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		}
		
		return status;
	}
}

