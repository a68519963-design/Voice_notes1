 package voicenotes.dao;

import voicenotes.beans.ContactBeans;
import voicenotes.beans.User;
import voicenotes.beans.UserFeedback;

import java.sql.*;
import java.util.ArrayList;

import vn.dbutil.DbConnection;

public class GuestDao {
	private Connection con;//it will hold refrences of  connected data base 
	
	
	
	//-----method  for acessing Feedbacks-----
	
	//id, name, email, rating, remarks, date
	//email, password, name, phone, city, address, profile_pic, date
	public ArrayList<User>allFeedBacks(){
		
		con=DbConnection.openConnection();	
	    String sql="select f.name,f.rating,f.remarks,u.profile_pic from userfeedback f,user u where u.email=f.email and f.rating='5' order by f.date DESC LIMIT 5 ";	
	   
	    User u=null;
	    UserFeedback feed=null;
	    
	    PreparedStatement ps=null;
	    ResultSet rs=null;
	    
	    ArrayList<User>UserList=new ArrayList<>();
	       
	    try {
	    	
	    	ps=con.prepareStatement(sql);
	    	rs=ps.executeQuery(); 
	    	
	    	while(rs.next()){
	    		
	    		String uName=rs.getString("name");
	    		String uRating=rs.getString("rating");
	    		 
	    		
	    		String uRemarks=rs.getString("remarks") ;
	    		String uPic=rs.getString("profile_pic");
	    		
	    		
	    		// creating  feedbacks bean class objects 
	    		
	    		feed=new UserFeedback();
	    		feed.setName(uName);
	    		feed.setRating(uRating);
	    		feed.setRemarks(uRemarks);
	    		
	    		//adding user obkect of user beans class
	    		
	    		u=new User();
	    		
	    		u.setProfile_pic(uPic);
	    		u.setFd(feed);
	    		
	    		UserList.add(u);
	    	}
	    }
	     catch(SQLException se){
	    	 
	    	 se.printStackTrace();
	     }
	    return UserList;
	}

	public int addCountactBeans(ContactBeans c) {
		
		
		con=DbConnection.openConnection();//connection established=> voice notes db 
		int status=0;	
		PreparedStatement ps=null;
		 
		
try {
	String strInsert="insert into contact( name, email, phone, query, date)values(?,?,?,?,?)";
	
	
	ps=con.prepareStatement(strInsert); 
	ps.setString(1,c.getName());
	ps.setString(2,c.getEmail());
	ps.setString(3,c.getPhone());
	ps.setString(4,c.getQuery());
	ps.setDate(5,c.getDate());
    System.out.println(ps);
    status=ps.executeUpdate();
    System.out.println("query status is "+status);
	
	//passes this 
	//query dbms compiler compile store it into buffer and assign the address 
	// of the buffer to the ps 
	
	
}
catch(SQLException se) {
	
	
	se.printStackTrace();
}
finally {
	
	try {
		if(ps!=null)
			ps.close();
		
		if(con!=null)
			con.close();
		
		
		
	}
	catch (SQLException se){
		se.printStackTrace();
	}
}
       return status;	
       
       
	}
	

}
