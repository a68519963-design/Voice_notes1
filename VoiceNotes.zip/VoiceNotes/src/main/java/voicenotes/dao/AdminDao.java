package voicenotes.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vn.dbutil.DbConnection;
import voicenotes.beans.ContactBeans;
import voicenotes.beans.User;
import voicenotes.beans.UserFeedback;

public class AdminDao {
	
private Connection con;

private ArrayList<UserFeedback> feedbacklist;
public 	ArrayList<UserFeedback>	viewAllFeedback()
{
	
	feedbacklist=new ArrayList<UserFeedback>();
	
	UserFeedback fb=null;;

	
	String sql="select * from userfeedback";
	con=DbConnection.openConnection();
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	try {
		ps=con.prepareStatement(sql);
		rs=ps.executeQuery();
			while(rs.next())
		{

			String name=rs.getString("name");
			
			String email=rs.getString("email");
			String remark=rs.getString("remarks");
			String rating=rs.getString("rating");
			Date d=rs.getDate("date");
			//name, emaill, rating, remark;
			fb=new UserFeedback(name, email, rating, remark, d);
			feedbacklist.add(fb);
		}
		
	}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	
	return feedbacklist;
	
}
	
 

	private ArrayList<ContactBeans> contactList;
	public 	ArrayList<ContactBeans>	viewAllContacts()
	{
		
		contactList=new ArrayList<ContactBeans>();
		
		ContactBeans c=null;
	
		
		String sql="select * from contact";
		con=DbConnection.openConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
				while(rs.next())
			{

				String name=rs.getString("name");
				
				String email=rs.getString("email");
				String question=rs.getString("query");
				String phone=rs.getString("phone");
				Date d=rs.getDate("date");
				c=new ContactBeans(name, email, phone, question, d);
				c.setId(rs.getInt("id"));
				contactList.add(c);
				
				//String name=rs.getString("name");
			}
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		return contactList;
		
	}
	

	public boolean login(String email, String pass) {
		
		if(email.equals("admin@gmail.com")&&pass.equals("admin"))
		return true;
		
		return false;
	}




private Connection con2;
private ArrayList<User> userList;

public ArrayList<User> viewAllUser()
{
	userList=new ArrayList<User>();
	User u=null;
	String sql="select * from user";
	con2=DbConnection.openConnection();
	PreparedStatement ps=null;
	ResultSet rs=null;
	try {
        ps = con2.prepareStatement(sql);//email, password, name, phone, city, address, profile_pic
        rs = ps.executeQuery();
        while(rs.next())
		{
        	String email=rs.getString("email");
        	String password=rs.getString("password");
        	String name=rs.getString("name");
        	String phone=rs.getString("phone");
        	String city=rs.getString("city");
        	String address=rs.getString("address");
        	String profile_pic=rs.getString("profile_pic");
        	Date date=rs.getDate("date");
        	u=new User(email, password, name, phone, city, address, profile_pic, date);
        	userList.add(u);
		}


	
}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	return userList;
	
	
}


public int deleteContact(String[] idArray) {
	// TODO Auto-generated method stub
	int status=0;
	
	con=DbConnection.openConnection();
	PreparedStatement ps=null;
	
	String deleteQuery="delete from contact where id=?";
	
	try {
		con.setAutoCommit(false);
		ps=con.prepareStatement(deleteQuery);
		for(int i=0; i<idArray.length; i++) {
			ps.setInt(1, Integer.parseInt(idArray[i]));
			ps.addBatch();//batch statment processing of delete query
		}
	
	
	int[] deleteStatus = ps.executeBatch();
	
	int flag=0;
	for(int i=0;i<deleteStatus.length;i++)
	{
		if(deleteStatus[i]<0)
		{
			flag=1;
			break;
	}
	}
    
	 if(flag==0)
	 {
		 status=1;
	 con.setAutoCommit(true);
	 return status;
	}
	
} 
 catch(SQLException se) {
	se.printStackTrace();
 }
	
	return status;
    }
}
